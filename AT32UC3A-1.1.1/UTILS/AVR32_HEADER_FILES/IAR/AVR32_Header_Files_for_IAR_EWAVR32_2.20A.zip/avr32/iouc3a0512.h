/**************************************************
 *
 * Declaration of system and I/O registers for AVR32
 * IAR C/C++ Compiler and IAR Assembler.
 *
 * This file describes the properties of the Atmel UC3A0512
 * device. It can be used directly, or as a template for
 * creating new I/O register description files.
 *
 * This file has been automatically generated from the corresponding
 * part description file from Atmel:
 * File name:           UC3A0512.xml
 * File version:        0
 * File release status: RELEASE
 * Last file update:    2007-01-26
 *
 * Copyright 2005 IAR Systems. All rights reserved.
 *
 * $Revision: 1.8 $
 *
 **************************************************/

#ifndef __IOUC3A0512_H
#define __IOUC3A0512_H

#if (!__AAVR32__ && !__ICCAVR32__)
#error "File iouc3a0512.h is for use with ICCAVR32/AAVR32 only."
#endif

#include <avr32/abi.h>

#ifdef __IAR_SYSTEMS_ICC__
#pragma language=extended

/* Core definition */
#include <avr32/core_sc0_100.h>

/* Interrupts */
#define AVR32_CORE_COMPARE_IRQ        0

#define AVR32_CORE_IRQ_GROUP          0

/* OnChipDebug module */
#include <avr32/ocd_s0_100.h>

/* Interrupt controller */
#include <avr32/intc.h>

/* Instances */
extern volatile __no_init avr32_intc_t AVR32_INTC @ 0xFFFF0800;

/* ADC - Analog to Digital Converter */
#include <avr32/adc_102.h>

/* Instances */
extern volatile __no_init avr32_adc_t AVR32_ADC @ 0xFFFF3C00;

/* EIC - External Interrupt Controller */
#include <avr32/eic_200.h>

/* Instances */

/*This instantiation is made below*/

/* Interrupts */
#define AVR32_EIC_INT0_IRQ            32
#define AVR32_EIC_INT1_IRQ            33
#define AVR32_EIC_INT2_IRQ            34
#define AVR32_EIC_INT3_IRQ            35
#define AVR32_EIC_INT4_IRQ            36
#define AVR32_EIC_INT5_IRQ            37
#define AVR32_EIC_INT6_IRQ            38
#define AVR32_EIC_INT7_IRQ            39

#define AVR32_EIC_IRQ_GROUP           1

/* FLASHC - Flash Controller */
#include <avr32/flashc_100.h>

/* Instances */
extern volatile __no_init avr32_flashc_t AVR32_FLASHC @ 0xFFFE1400;

/* Interrupts */
#define AVR32_FLASHC_FCLOCKE_IRQ      128
#define AVR32_FLASHC_FCPROGE_IRQ      128
#define AVR32_FLASHC_FCRDY_IRQ        128

#define AVR32_FLASHC_IRQ_GROUP        4

/* FREQM - Frequency Meter */
#include <avr32/freqm_200.h>

/* Instances */

/*This instantiation is made below*/

/* GPIO - General Purpose Input/Output Controller */
#define IAR_AVR32_GPIO_INSTANCE 4
#include <avr32/gpio_100.h>

/* Instances */
extern volatile __no_init avr32_gpio_t AVR32_GPIO @ 0xFFFF1000;

/* Interrupts */
#define AVR32_GPIO_IRQ0_IRQ           64
#define AVR32_GPIO_IRQ1_IRQ           64
#define AVR32_GPIO_IRQ2_IRQ           64
#define AVR32_GPIO_IRQ3_IRQ           64
#define AVR32_GPIO_IRQ4_IRQ           64
#define AVR32_GPIO_IRQ5_IRQ           64
#define AVR32_GPIO_IRQ6_IRQ           64
#define AVR32_GPIO_IRQ7_IRQ           64
#define AVR32_GPIO_IRQ8_IRQ           65
#define AVR32_GPIO_IRQ9_IRQ           65
#define AVR32_GPIO_IRQ10_IRQ          65
#define AVR32_GPIO_IRQ11_IRQ          65
#define AVR32_GPIO_IRQ12_IRQ          65
#define AVR32_GPIO_IRQ13_IRQ          65
#define AVR32_GPIO_IRQ14_IRQ          65
#define AVR32_GPIO_IRQ15_IRQ          65
#define AVR32_GPIO_IRQ16_IRQ          66
#define AVR32_GPIO_IRQ17_IRQ          66
#define AVR32_GPIO_IRQ18_IRQ          66
#define AVR32_GPIO_IRQ19_IRQ          66
#define AVR32_GPIO_IRQ20_IRQ          66
#define AVR32_GPIO_IRQ21_IRQ          66
#define AVR32_GPIO_IRQ22_IRQ          66
#define AVR32_GPIO_IRQ23_IRQ          66
#define AVR32_GPIO_IRQ24_IRQ          67
#define AVR32_GPIO_IRQ25_IRQ          67
#define AVR32_GPIO_IRQ26_IRQ          67
#define AVR32_GPIO_IRQ27_IRQ          67
#define AVR32_GPIO_IRQ28_IRQ          67
#define AVR32_GPIO_IRQ29_IRQ          67
#define AVR32_GPIO_IRQ30_IRQ          67
#define AVR32_GPIO_IRQ31_IRQ          67
#define AVR32_GPIO_IRQ32_IRQ          68
#define AVR32_GPIO_IRQ33_IRQ          68
#define AVR32_GPIO_IRQ34_IRQ          68
#define AVR32_GPIO_IRQ35_IRQ          68
#define AVR32_GPIO_IRQ36_IRQ          68
#define AVR32_GPIO_IRQ37_IRQ          68
#define AVR32_GPIO_IRQ38_IRQ          68
#define AVR32_GPIO_IRQ39_IRQ          68
#define AVR32_GPIO_IRQ40_IRQ          69
#define AVR32_GPIO_IRQ41_IRQ          69
#define AVR32_GPIO_IRQ42_IRQ          69
#define AVR32_GPIO_IRQ43_IRQ          69
#define AVR32_GPIO_IRQ44_IRQ          69
#define AVR32_GPIO_IRQ45_IRQ          69
#define AVR32_GPIO_IRQ46_IRQ          69
#define AVR32_GPIO_IRQ47_IRQ          69
#define AVR32_GPIO_IRQ48_IRQ          70
#define AVR32_GPIO_IRQ49_IRQ          70
#define AVR32_GPIO_IRQ50_IRQ          70
#define AVR32_GPIO_IRQ51_IRQ          70
#define AVR32_GPIO_IRQ52_IRQ          70
#define AVR32_GPIO_IRQ53_IRQ          70
#define AVR32_GPIO_IRQ54_IRQ          70
#define AVR32_GPIO_IRQ55_IRQ          70
#define AVR32_GPIO_IRQ56_IRQ          71
#define AVR32_GPIO_IRQ57_IRQ          71
#define AVR32_GPIO_IRQ58_IRQ          71
#define AVR32_GPIO_IRQ59_IRQ          71
#define AVR32_GPIO_IRQ60_IRQ          71
#define AVR32_GPIO_IRQ61_IRQ          71
#define AVR32_GPIO_IRQ62_IRQ          71
#define AVR32_GPIO_IRQ63_IRQ          71
#define AVR32_GPIO_IRQ64_IRQ          72
#define AVR32_GPIO_IRQ65_IRQ          72
#define AVR32_GPIO_IRQ66_IRQ          72
#define AVR32_GPIO_IRQ67_IRQ          72
#define AVR32_GPIO_IRQ68_IRQ          72
#define AVR32_GPIO_IRQ69_IRQ          72
#define AVR32_GPIO_IRQ70_IRQ          72
#define AVR32_GPIO_IRQ71_IRQ          72
#define AVR32_GPIO_IRQ72_IRQ          73
#define AVR32_GPIO_IRQ73_IRQ          73
#define AVR32_GPIO_IRQ74_IRQ          73
#define AVR32_GPIO_IRQ75_IRQ          73
#define AVR32_GPIO_IRQ76_IRQ          73
#define AVR32_GPIO_IRQ77_IRQ          73
#define AVR32_GPIO_IRQ78_IRQ          73
#define AVR32_GPIO_IRQ79_IRQ          73
#define AVR32_GPIO_IRQ80_IRQ          74
#define AVR32_GPIO_IRQ81_IRQ          74
#define AVR32_GPIO_IRQ82_IRQ          74
#define AVR32_GPIO_IRQ83_IRQ          74
#define AVR32_GPIO_IRQ84_IRQ          74
#define AVR32_GPIO_IRQ85_IRQ          74
#define AVR32_GPIO_IRQ86_IRQ          74
#define AVR32_GPIO_IRQ87_IRQ          74
#define AVR32_GPIO_IRQ88_IRQ          75
#define AVR32_GPIO_IRQ89_IRQ          75
#define AVR32_GPIO_IRQ90_IRQ          75
#define AVR32_GPIO_IRQ91_IRQ          75
#define AVR32_GPIO_IRQ92_IRQ          75
#define AVR32_GPIO_IRQ93_IRQ          75
#define AVR32_GPIO_IRQ94_IRQ          75
#define AVR32_GPIO_IRQ95_IRQ          75
#define AVR32_GPIO_IRQ96_IRQ          76
#define AVR32_GPIO_IRQ97_IRQ          76
#define AVR32_GPIO_IRQ98_IRQ          76
#define AVR32_GPIO_IRQ99_IRQ          76
#define AVR32_GPIO_IRQ100_IRQ         76
#define AVR32_GPIO_IRQ101_IRQ         76
#define AVR32_GPIO_IRQ102_IRQ         76
#define AVR32_GPIO_IRQ103_IRQ         76
#define AVR32_GPIO_IRQ104_IRQ         77
#define AVR32_GPIO_IRQ105_IRQ         77
#define AVR32_GPIO_IRQ106_IRQ         77
#define AVR32_GPIO_IRQ107_IRQ         77
#define AVR32_GPIO_IRQ108_IRQ         77
#define AVR32_GPIO_IRQ109_IRQ         77
#define AVR32_GPIO_IRQ110_IRQ         77
#define AVR32_GPIO_IRQ111_IRQ         77

#define AVR32_GPIO_IRQ_GROUP          2

/* HMATRIX - HSB Matrix */
#include <avr32/hmatrix_220.h>

/* Instances */
extern volatile __no_init avr32_hmatrix_t AVR32_HMATRIX @ 0xFFFE1000;

/* MACB - Ethernet MAC */
#include <avr32/macb_112.h>

/* Instances */
extern volatile __no_init avr32_macb_t AVR32_MACB @ 0xFFFE1800;

/* Interrupts */
#define AVR32_MACB_HRESP_IRQ          512
#define AVR32_MACB_LINK_IRQ           512
#define AVR32_MACB_MFD_IRQ            512
#define AVR32_MACB_PFR_IRQ            512
#define AVR32_MACB_PTZ_IRQ            512
#define AVR32_MACB_RCOMP_IRQ          512
#define AVR32_MACB_RLE_IRQ            512
#define AVR32_MACB_ROVR_IRQ           512
#define AVR32_MACB_RXUBR_IRQ          512
#define AVR32_MACB_TCOMP_IRQ          512
#define AVR32_MACB_TUND_IRQ           512
#define AVR32_MACB_TXERR_IRQ          512
#define AVR32_MACB_TXUBR_IRQ          512

#define AVR32_MACB_IRQ_GROUP          16

/* PDCA - Peripheral DMA Controller */
#define IAR_AVR32_PDCA_INSTANCE 15
#include <avr32/pdca_100.h>

/* Instances */
extern volatile __no_init avr32_pdca_t AVR32_PDCA @ 0xFFFF0000;

/* Interrupts */
#define AVR32_PDCA_RCZ0_IRQ           96
#define AVR32_PDCA_RCZ1_IRQ           97
#define AVR32_PDCA_RCZ2_IRQ           98
#define AVR32_PDCA_RCZ3_IRQ           99
#define AVR32_PDCA_RCZ4_IRQ           100
#define AVR32_PDCA_RCZ5_IRQ           101
#define AVR32_PDCA_RCZ6_IRQ           102
#define AVR32_PDCA_RCZ7_IRQ           103
#define AVR32_PDCA_RCZ8_IRQ           104
#define AVR32_PDCA_RCZ9_IRQ           105
#define AVR32_PDCA_RCZ10_IRQ          106
#define AVR32_PDCA_RCZ11_IRQ          107
#define AVR32_PDCA_RCZ12_IRQ          108
#define AVR32_PDCA_RCZ13_IRQ          109
#define AVR32_PDCA_RCZ14_IRQ          110
#define AVR32_PDCA_TERR0_IRQ          96
#define AVR32_PDCA_TERR1_IRQ          97
#define AVR32_PDCA_TERR2_IRQ          98
#define AVR32_PDCA_TERR3_IRQ          99
#define AVR32_PDCA_TERR4_IRQ          100
#define AVR32_PDCA_TERR5_IRQ          101
#define AVR32_PDCA_TERR6_IRQ          102
#define AVR32_PDCA_TERR7_IRQ          103
#define AVR32_PDCA_TERR8_IRQ          104
#define AVR32_PDCA_TERR9_IRQ          105
#define AVR32_PDCA_TERR10_IRQ         106
#define AVR32_PDCA_TERR11_IRQ         107
#define AVR32_PDCA_TERR12_IRQ         108
#define AVR32_PDCA_TERR13_IRQ         109
#define AVR32_PDCA_TERR14_IRQ         110
#define AVR32_PDCA_TRC0_IRQ           96
#define AVR32_PDCA_TRC1_IRQ           97
#define AVR32_PDCA_TRC2_IRQ           98
#define AVR32_PDCA_TRC3_IRQ           99
#define AVR32_PDCA_TRC4_IRQ           100
#define AVR32_PDCA_TRC5_IRQ           101
#define AVR32_PDCA_TRC6_IRQ           102
#define AVR32_PDCA_TRC7_IRQ           103
#define AVR32_PDCA_TRC8_IRQ           104
#define AVR32_PDCA_TRC9_IRQ           105
#define AVR32_PDCA_TRC10_IRQ          106
#define AVR32_PDCA_TRC11_IRQ          107
#define AVR32_PDCA_TRC12_IRQ          108
#define AVR32_PDCA_TRC13_IRQ          109
#define AVR32_PDCA_TRC14_IRQ          110

#define AVR32_PDCA_IRQ_GROUP          3

/* PM - Power Manager */
#include <avr32/pm_200.h>

/* Instances */

/*This instantiation is made below*/

/* Interrupts */
#define AVR32_PM_LOCK0_IRQ            41
#define AVR32_PM_LOCK1_IRQ            41

#define AVR32_PM_IRQ_GROUP            1

/* PWM - Pulse Width Modulation Controller */
#define IAR_AVR32_PWM_INSTANCE 7
#include <avr32/pwm_120.h>

/* Instances */
extern volatile __no_init avr32_pwm_t AVR32_PWM @ 0xFFFF3000;

/* Interrupts */
#define AVR32_PWM_CHANNEL0_IRQ        384
#define AVR32_PWM_CHANNEL1_IRQ        384
#define AVR32_PWM_CHANNEL2_IRQ        384
#define AVR32_PWM_CHANNEL3_IRQ        384
#define AVR32_PWM_CHANNEL4_IRQ        384
#define AVR32_PWM_CHANNEL5_IRQ        384
#define AVR32_PWM_CHANNEL6_IRQ        384

#define AVR32_PWM_IRQ_GROUP           12

/* RTC - Real Time Counter */
#include <avr32/rtc_200.h>

/* Instances */

/*This instantiation is made below*/

/* Interrupts */
#define AVR32_RTC_TOPI_IRQ            40

#define AVR32_RTC_IRQ_GROUP           1

/* SDRAMC - SDRAM Controller */
#include <avr32/sdramc_201.h>

/* Instances */
extern volatile __no_init avr32_sdramc_t AVR32_SDRAMC @ 0xFFFE2000;

/* Interrupts */
#define AVR32_SDRAMC_SDRAMCINTERRUPT_IRQ576

#define AVR32_SDRAMC_IRQ_GROUP        18

/* SMC - Static Memory Controller */
#include <avr32/smc_104.h>

/* Instances */
extern volatile __no_init avr32_smc_t AVR32_SMC @ 0xFFFE1C00;

/* SPI - Serial Peripheral Interface */
#include <avr32/spi_192.h>

/* Instances */
extern volatile __no_init avr32_spi_t AVR32_SPI0 @ 0xFFFF2400;
extern volatile __no_init avr32_spi_t AVR32_SPI1 @ 0xFFFF2800;

/* Interrupts */
#define AVR32_SPI0_ENDRX_IRQ          288
#define AVR32_SPI0_ENDTX_IRQ          288
#define AVR32_SPI0_MODF_IRQ           288
#define AVR32_SPI0_NSSR_IRQ           288
#define AVR32_SPI0_OVRES_IRQ          288
#define AVR32_SPI0_RDRF_IRQ           288
#define AVR32_SPI0_RXBUFF_IRQ         288
#define AVR32_SPI0_TDRE_IRQ           288
#define AVR32_SPI0_TXBUFE_IRQ         288
#define AVR32_SPI0_TXEMPTY_IRQ        288

#define AVR32_SPI0_IRQ_GROUP          9

/* Interrupts */
#define AVR32_SPI1_ENDRX_IRQ          320
#define AVR32_SPI1_ENDTX_IRQ          320
#define AVR32_SPI1_MODF_IRQ           320
#define AVR32_SPI1_NSSR_IRQ           320
#define AVR32_SPI1_OVRES_IRQ          320
#define AVR32_SPI1_RDRF_IRQ           320
#define AVR32_SPI1_RXBUFF_IRQ         320
#define AVR32_SPI1_TDRE_IRQ           320
#define AVR32_SPI1_TXBUFE_IRQ         320
#define AVR32_SPI1_TXEMPTY_IRQ        320

#define AVR32_SPI1_IRQ_GROUP          10

/* SSC - Synchronous Serial Controller */
#include <avr32/ssc_301.h>

/* Instances */
extern volatile __no_init avr32_ssc_t AVR32_SSC @ 0xFFFF3400;

/* Interrupts */
#define AVR32_SSC_CP0_IRQ             416
#define AVR32_SSC_CP1_IRQ             416
#define AVR32_SSC_ENDRX_IRQ           416
#define AVR32_SSC_ENDTX_IRQ           416
#define AVR32_SSC_OVRUN_IRQ           416
#define AVR32_SSC_RXBUFF_IRQ          416
#define AVR32_SSC_RXRDY_IRQ           416
#define AVR32_SSC_RXSYN_IRQ           416
#define AVR32_SSC_TXBUFE_IRQ          416
#define AVR32_SSC_TXEMPTY_IRQ         416
#define AVR32_SSC_TXRDY_IRQ           416
#define AVR32_SSC_TXSYN_IRQ           416

#define AVR32_SSC_IRQ_GROUP           13

/* TC - Timer/Counter */
#include <avr32/tc_222.h>

/* Instances */
extern volatile __no_init avr32_tc_t AVR32_TC @ 0xFFFF3800;

/* Interrupts */
#define AVR32_TC_COVFS0_IRQ           448
#define AVR32_TC_COVFS1_IRQ           449
#define AVR32_TC_COVFS2_IRQ           450
#define AVR32_TC_CPAS0_IRQ            448
#define AVR32_TC_CPAS1_IRQ            449
#define AVR32_TC_CPAS2_IRQ            450
#define AVR32_TC_CPBS0_IRQ            448
#define AVR32_TC_CPBS1_IRQ            449
#define AVR32_TC_CPBS2_IRQ            450
#define AVR32_TC_CPCS0_IRQ            448
#define AVR32_TC_CPCS1_IRQ            449
#define AVR32_TC_CPCS2_IRQ            450
#define AVR32_TC_ETRGS0_IRQ           448
#define AVR32_TC_ETRGS1_IRQ           450
#define AVR32_TC_ETRGS2_IRQ           449
#define AVR32_TC_LDRAS0_IRQ           448
#define AVR32_TC_LDRAS1_IRQ           449
#define AVR32_TC_LDRAS2_IRQ           450
#define AVR32_TC_LDRBS0_IRQ           448
#define AVR32_TC_LDRBS1_IRQ           449
#define AVR32_TC_LDRBS2_IRQ           450
#define AVR32_TC_LOVRS0_IRQ           448
#define AVR32_TC_LOVRS1_IRQ           449
#define AVR32_TC_LOVRS2_IRQ           450

#define AVR32_TC_IRQ_GROUP            14

/* TWI - Two-wire Interface */
#include <avr32/twi_202.h>

/* Instances */
extern volatile __no_init avr32_twi_t AVR32_TWI @ 0xFFFF2C00;

/* Interrupts */
#define AVR32_TWI_ARBLST_IRQ          352
#define AVR32_TWI_ENDRX_IRQ           352
#define AVR32_TWI_ENDTX_IRQ           352
#define AVR32_TWI_EOSACC_IRQ          352
#define AVR32_TWI_GACC_IRQ            352
#define AVR32_TWI_NACK_IRQ            352
#define AVR32_TWI_OVRE_IRQ            352
#define AVR32_TWI_RXBUFF_IRQ          352
#define AVR32_TWI_RXRDY_IRQ           352
#define AVR32_TWI_SCLWS_IRQ           352
#define AVR32_TWI_SVACK_IRQ           352
#define AVR32_TWI_TXBUFE_IRQ          352
#define AVR32_TWI_TXCOMP_IRQ          352
#define AVR32_TWI_TXRDY_IRQ           352

#define AVR32_TWI_IRQ_GROUP           11

/* USART - Universal Synchronous Asynchronous Receiver Transmitter */
#include <avr32/usart_319.h>

/* Instances */
extern volatile __no_init avr32_usart_t AVR32_USART0 @ 0xFFFF1400;
extern volatile __no_init avr32_usart_t AVR32_USART1 @ 0xFFFF1800;
extern volatile __no_init avr32_usart_t AVR32_USART2 @ 0xFFFF1C00;
extern volatile __no_init avr32_usart_t AVR32_USART3 @ 0xFFFF2000;

/* Interrupts */
#define AVR32_USART0_COMM_RX_IRQ      160
#define AVR32_USART0_COMM_TX_IRQ      160
#define AVR32_USART0_CTSIC_IRQ        160
#define AVR32_USART0_DCDIC_IRQ        160
#define AVR32_USART0_DSRIC_IRQ        160
#define AVR32_USART0_ENDRX_IRQ        160
#define AVR32_USART0_ENDTX_IRQ        160
#define AVR32_USART0_FRAME_IRQ        160
#define AVR32_USART0_ITERATION_IRQ    160
#define AVR32_USART0_NACK_IRQ         160
#define AVR32_USART0_OVRE_IRQ         160
#define AVR32_USART0_PARE_IRQ         160
#define AVR32_USART0_RIIC_IRQ         160
#define AVR32_USART0_RXBRK_IRQ        160
#define AVR32_USART0_RXBUFF_IRQ       160
#define AVR32_USART0_RXRDY_IRQ        160
#define AVR32_USART0_TIMEOUT_IRQ      160
#define AVR32_USART0_TXBUFE_IRQ       160
#define AVR32_USART0_TXEMPTY_IRQ      160
#define AVR32_USART0_TXRDY_IRQ        160

#define AVR32_USART0_IRQ_GROUP        5

/* Interrupts */
#define AVR32_USART1_COMM_RX_IRQ      192
#define AVR32_USART1_COMM_TX_IRQ      192
#define AVR32_USART1_CTSIC_IRQ        192
#define AVR32_USART1_DCDIC_IRQ        192
#define AVR32_USART1_DSRIC_IRQ        192
#define AVR32_USART1_ENDRX_IRQ        192
#define AVR32_USART1_ENDTX_IRQ        192
#define AVR32_USART1_FRAME_IRQ        192
#define AVR32_USART1_ITERATION_IRQ    192
#define AVR32_USART1_NACK_IRQ         192
#define AVR32_USART1_OVRE_IRQ         192
#define AVR32_USART1_PARE_IRQ         192
#define AVR32_USART1_RIIC_IRQ         192
#define AVR32_USART1_RXBRK_IRQ        192
#define AVR32_USART1_RXBUFF_IRQ       192
#define AVR32_USART1_RXRDY_IRQ        192
#define AVR32_USART1_TIMEOUT_IRQ      192
#define AVR32_USART1_TXBUFE_IRQ       192
#define AVR32_USART1_TXEMPTY_IRQ      192
#define AVR32_USART1_TXRDY_IRQ        192

#define AVR32_USART1_IRQ_GROUP        6

/* Interrupts */
#define AVR32_USART2_COMM_RX_IRQ      224
#define AVR32_USART2_COMM_TX_IRQ      224
#define AVR32_USART2_CTSIC_IRQ        224
#define AVR32_USART2_DCDIC_IRQ        224
#define AVR32_USART2_DSRIC_IRQ        224
#define AVR32_USART2_ENDRX_IRQ        224
#define AVR32_USART2_ENDTX_IRQ        224
#define AVR32_USART2_FRAME_IRQ        224
#define AVR32_USART2_ITERATION_IRQ    224
#define AVR32_USART2_NACK_IRQ         224
#define AVR32_USART2_OVRE_IRQ         224
#define AVR32_USART2_PARE_IRQ         224
#define AVR32_USART2_RIIC_IRQ         224
#define AVR32_USART2_RXBRK_IRQ        224
#define AVR32_USART2_RXBUFF_IRQ       224
#define AVR32_USART2_RXRDY_IRQ        224
#define AVR32_USART2_TIMEOUT_IRQ      224
#define AVR32_USART2_TXBUFE_IRQ       224
#define AVR32_USART2_TXEMPTY_IRQ      224
#define AVR32_USART2_TXRDY_IRQ        224

#define AVR32_USART2_IRQ_GROUP        7

/* Interrupts */
#define AVR32_USART3_COMM_RX_IRQ      256
#define AVR32_USART3_COMM_TX_IRQ      256
#define AVR32_USART3_CTSIC_IRQ        256
#define AVR32_USART3_DCDIC_IRQ        256
#define AVR32_USART3_DSRIC_IRQ        256
#define AVR32_USART3_ENDRX_IRQ        256
#define AVR32_USART3_ENDTX_IRQ        256
#define AVR32_USART3_FRAME_IRQ        256
#define AVR32_USART3_ITERATION_IRQ    256
#define AVR32_USART3_NACK_IRQ         256
#define AVR32_USART3_OVRE_IRQ         256
#define AVR32_USART3_PARE_IRQ         256
#define AVR32_USART3_RIIC_IRQ         256
#define AVR32_USART3_RXBRK_IRQ        256
#define AVR32_USART3_RXBUFF_IRQ       256
#define AVR32_USART3_RXRDY_IRQ        256
#define AVR32_USART3_TIMEOUT_IRQ      256
#define AVR32_USART3_TXBUFE_IRQ       256
#define AVR32_USART3_TXEMPTY_IRQ      256
#define AVR32_USART3_TXRDY_IRQ        256

#define AVR32_USART3_IRQ_GROUP        8

/* USBB - USB Interface */
#include <avr32/usbb_260.h>

/* Instances */
extern volatile __no_init avr32_usbb_t AVR32_USBB @ 0xFFFE0000;

/* Interrupts */
#define AVR32_USBB_USB_IRQ_IRQ        544

#define AVR32_USBB_IRQ_GROUP          17

/* WDT - Watchdog Timer */
#include <avr32/wdt_200.h>

/* Instances */

/*This instantiation is made below*/


/*Here is the instantiation for RTC,WDT,FREQM,EIC, and PM*/
volatile __no_init union
{
  struct
  {
    unsigned long _pad_AVR32_RTC[0x40];
    avr32_wdt_t AVR32_RTC; /* @ 0xFFFF0D00 */
  };
  struct
  {
    unsigned long _pad_AVR32_WDT[0x4C];
    avr32_wdt_t AVR32_WDT; /* @ 0xFFFF0D30 */
  };
  struct
  {
    unsigned long _pad_AVR32_FREQM[0x54];
    avr32_wdt_t AVR32_FREQM; /* @ 0xFFFF0D50 */
  };
  struct
  {
    unsigned long _pad_AVR32_EIC[0x60];
    avr32_wdt_t AVR32_EIC; /* @ 0xFFFF0D80 */
  };
  struct
  {
    avr32_pm_t AVR32_PM; /* @ 0xFFFF0C00; */
  };
}@ 0xFFFF0C00;

/**************************************************
 *   System registers
 **************************************************/
typedef struct avr32_core_t
{
  /* 0x000 */
  union {
    unsigned long             sr;
    avr32_sr_t                SR;
  };
  unsigned long               evba;
  unsigned long               acba;
  union {
    unsigned long             cpucr;
    avr32_cpucr_t             CPUCR;
  };
  unsigned long const         ecr;

  unsigned long               _pad1[7];

  /* 0x030 */
  unsigned long               rsr_dbg;

  unsigned long               _pad2[7];

  /* 0x050 */
  unsigned long               rar_dbg;

  unsigned long               _pad3[43];

  /* 0x100 */
  union {
    unsigned long const       config0;
    avr32_config0_t const     CONFIG0;
  };
  union {
    unsigned long const       config1;
    avr32_config1_t const     CONFIG1;
  };
  unsigned long               count;
  unsigned long               compare;

  unsigned long               _pad4[11];

  /* 0x13C */
  unsigned long               bear;
  union {
    unsigned long             mpuari0;
    avr32_mpuari0_t           MPUARI0;
  };
  union {
    unsigned long             mpuari1;
    avr32_mpuari1_t           MPUARI1;
  };
  union {
    unsigned long             mpuari2;
    avr32_mpuari2_t           MPUARI2;
  };
  union {
    unsigned long             mpuari3;
    avr32_mpuari3_t           MPUARI3;
  };
  union {
    unsigned long             mpuari4;
    avr32_mpuari4_t           MPUARI4;
  };
  union {
    unsigned long             mpuari5;
    avr32_mpuari5_t           MPUARI5;
  };
  union {
    unsigned long             mpuari6;
    avr32_mpuari6_t           MPUARI6;
  };
  union {
    unsigned long             mpuari7;
    avr32_mpuari7_t           MPUARI7;
  };
  union {
    unsigned long             mpuard0;
    avr32_mpuard0_t           MPUARD0;
  };
  union {
    unsigned long             mpuard1;
    avr32_mpuard1_t           MPUARD1;
  };
  union {
    unsigned long             mpuard2;
    avr32_mpuard2_t           MPUARD2;
  };
  union {
    unsigned long             mpuard3;
    avr32_mpuard3_t           MPUARD3;
  };
  union {
    unsigned long             mpuard4;
    avr32_mpuard4_t           MPUARD4;
  };
  union {
    unsigned long             mpuard5;
    avr32_mpuard5_t           MPUARD5;
  };
  union {
    unsigned long             mpuard6;
    avr32_mpuard6_t           MPUARD6;
  };
  union {
    unsigned long             mpuard7;
    avr32_mpuard7_t           MPUARD7;
  };
  union {
    unsigned long             mpucri;
    avr32_mpucri_t            MPUCRI;
  };
  union {
    unsigned long             mpucrd;
    avr32_mpucrd_t            MPUCRD;
  };
  union {
    unsigned long             mpubrd;
    avr32_mpubrd_t            MPUBRD;
  };
  union {
    unsigned long             mpuapri;
    avr32_mpuapri_t           MPUAPRI;
  };
  union {
    unsigned long             mpuaprd;
    avr32_mpuaprd_t           MPUAPRD;
  };
  union {
    unsigned long             mpucr;
    avr32_mpucr_t             MPUCR;
  };
} avr32_core_t;

/* instance */
extern volatile __no_init __sysreg avr32_core_t avr32_core @ 0x000;

/**************************************************
 *   Non-volatile registers
 **************************************************/

#pragma language=default
#endif  /* __IAR_SYSTEMS_ICC__  */
#ifdef __IAR_SYSTEMS_ASM__

/**************************************************
 *   Non-volatile registers
 **************************************************/

/* Instances */
AVR32_ADC DEFINE 0xFFFF3C00

/* Instances */
AVR32_EIC DEFINE 0xFFFF0D80

/* Interrupts */
#define AVR32_EIC_INT0_IRQ            32
#define AVR32_EIC_INT1_IRQ            33
#define AVR32_EIC_INT2_IRQ            34
#define AVR32_EIC_INT3_IRQ            35
#define AVR32_EIC_INT4_IRQ            36
#define AVR32_EIC_INT5_IRQ            37
#define AVR32_EIC_INT6_IRQ            38
#define AVR32_EIC_INT7_IRQ            39

#define AVR32_EIC_IRQ_GROUP           1

/* Instances */
AVR32_FLASHC DEFINE 0xFFFE1400

/* Interrupts */
#define AVR32_FLASHC_FCLOCKE_IRQ      128
#define AVR32_FLASHC_FCPROGE_IRQ      128
#define AVR32_FLASHC_FCRDY_IRQ        128

#define AVR32_FLASHC_IRQ_GROUP        4

/* Instances */
AVR32_FREQM DEFINE 0xFFFF0D50

/* Instances */
AVR32_GPIO DEFINE 0xFFFF1000

/* Interrupts */
#define AVR32_GPIO_IRQ0_IRQ           64
#define AVR32_GPIO_IRQ1_IRQ           64
#define AVR32_GPIO_IRQ2_IRQ           64
#define AVR32_GPIO_IRQ3_IRQ           64
#define AVR32_GPIO_IRQ4_IRQ           64
#define AVR32_GPIO_IRQ5_IRQ           64
#define AVR32_GPIO_IRQ6_IRQ           64
#define AVR32_GPIO_IRQ7_IRQ           64
#define AVR32_GPIO_IRQ8_IRQ           65
#define AVR32_GPIO_IRQ9_IRQ           65
#define AVR32_GPIO_IRQ10_IRQ          65
#define AVR32_GPIO_IRQ11_IRQ          65
#define AVR32_GPIO_IRQ12_IRQ          65
#define AVR32_GPIO_IRQ13_IRQ          65
#define AVR32_GPIO_IRQ14_IRQ          65
#define AVR32_GPIO_IRQ15_IRQ          65
#define AVR32_GPIO_IRQ16_IRQ          66
#define AVR32_GPIO_IRQ17_IRQ          66
#define AVR32_GPIO_IRQ18_IRQ          66
#define AVR32_GPIO_IRQ19_IRQ          66
#define AVR32_GPIO_IRQ20_IRQ          66
#define AVR32_GPIO_IRQ21_IRQ          66
#define AVR32_GPIO_IRQ22_IRQ          66
#define AVR32_GPIO_IRQ23_IRQ          66
#define AVR32_GPIO_IRQ24_IRQ          67
#define AVR32_GPIO_IRQ25_IRQ          67
#define AVR32_GPIO_IRQ26_IRQ          67
#define AVR32_GPIO_IRQ27_IRQ          67
#define AVR32_GPIO_IRQ28_IRQ          67
#define AVR32_GPIO_IRQ29_IRQ          67
#define AVR32_GPIO_IRQ30_IRQ          67
#define AVR32_GPIO_IRQ31_IRQ          67
#define AVR32_GPIO_IRQ32_IRQ          68
#define AVR32_GPIO_IRQ33_IRQ          68
#define AVR32_GPIO_IRQ34_IRQ          68
#define AVR32_GPIO_IRQ35_IRQ          68
#define AVR32_GPIO_IRQ36_IRQ          68
#define AVR32_GPIO_IRQ37_IRQ          68
#define AVR32_GPIO_IRQ38_IRQ          68
#define AVR32_GPIO_IRQ39_IRQ          68
#define AVR32_GPIO_IRQ40_IRQ          69
#define AVR32_GPIO_IRQ41_IRQ          69
#define AVR32_GPIO_IRQ42_IRQ          69
#define AVR32_GPIO_IRQ43_IRQ          69
#define AVR32_GPIO_IRQ44_IRQ          69
#define AVR32_GPIO_IRQ45_IRQ          69
#define AVR32_GPIO_IRQ46_IRQ          69
#define AVR32_GPIO_IRQ47_IRQ          69
#define AVR32_GPIO_IRQ48_IRQ          70
#define AVR32_GPIO_IRQ49_IRQ          70
#define AVR32_GPIO_IRQ50_IRQ          70
#define AVR32_GPIO_IRQ51_IRQ          70
#define AVR32_GPIO_IRQ52_IRQ          70
#define AVR32_GPIO_IRQ53_IRQ          70
#define AVR32_GPIO_IRQ54_IRQ          70
#define AVR32_GPIO_IRQ55_IRQ          70
#define AVR32_GPIO_IRQ56_IRQ          71
#define AVR32_GPIO_IRQ57_IRQ          71
#define AVR32_GPIO_IRQ58_IRQ          71
#define AVR32_GPIO_IRQ59_IRQ          71
#define AVR32_GPIO_IRQ60_IRQ          71
#define AVR32_GPIO_IRQ61_IRQ          71
#define AVR32_GPIO_IRQ62_IRQ          71
#define AVR32_GPIO_IRQ63_IRQ          71
#define AVR32_GPIO_IRQ64_IRQ          72
#define AVR32_GPIO_IRQ65_IRQ          72
#define AVR32_GPIO_IRQ66_IRQ          72
#define AVR32_GPIO_IRQ67_IRQ          72
#define AVR32_GPIO_IRQ68_IRQ          72
#define AVR32_GPIO_IRQ69_IRQ          72
#define AVR32_GPIO_IRQ70_IRQ          72
#define AVR32_GPIO_IRQ71_IRQ          72
#define AVR32_GPIO_IRQ72_IRQ          73
#define AVR32_GPIO_IRQ73_IRQ          73
#define AVR32_GPIO_IRQ74_IRQ          73
#define AVR32_GPIO_IRQ75_IRQ          73
#define AVR32_GPIO_IRQ76_IRQ          73
#define AVR32_GPIO_IRQ77_IRQ          73
#define AVR32_GPIO_IRQ78_IRQ          73
#define AVR32_GPIO_IRQ79_IRQ          73
#define AVR32_GPIO_IRQ80_IRQ          74
#define AVR32_GPIO_IRQ81_IRQ          74
#define AVR32_GPIO_IRQ82_IRQ          74
#define AVR32_GPIO_IRQ83_IRQ          74
#define AVR32_GPIO_IRQ84_IRQ          74
#define AVR32_GPIO_IRQ85_IRQ          74
#define AVR32_GPIO_IRQ86_IRQ          74
#define AVR32_GPIO_IRQ87_IRQ          74
#define AVR32_GPIO_IRQ88_IRQ          75
#define AVR32_GPIO_IRQ89_IRQ          75
#define AVR32_GPIO_IRQ90_IRQ          75
#define AVR32_GPIO_IRQ91_IRQ          75
#define AVR32_GPIO_IRQ92_IRQ          75
#define AVR32_GPIO_IRQ93_IRQ          75
#define AVR32_GPIO_IRQ94_IRQ          75
#define AVR32_GPIO_IRQ95_IRQ          75
#define AVR32_GPIO_IRQ96_IRQ          76
#define AVR32_GPIO_IRQ97_IRQ          76
#define AVR32_GPIO_IRQ98_IRQ          76
#define AVR32_GPIO_IRQ99_IRQ          76
#define AVR32_GPIO_IRQ100_IRQ         76
#define AVR32_GPIO_IRQ101_IRQ         76
#define AVR32_GPIO_IRQ102_IRQ         76
#define AVR32_GPIO_IRQ103_IRQ         76
#define AVR32_GPIO_IRQ104_IRQ         77
#define AVR32_GPIO_IRQ105_IRQ         77
#define AVR32_GPIO_IRQ106_IRQ         77
#define AVR32_GPIO_IRQ107_IRQ         77
#define AVR32_GPIO_IRQ108_IRQ         77
#define AVR32_GPIO_IRQ109_IRQ         77
#define AVR32_GPIO_IRQ110_IRQ         77
#define AVR32_GPIO_IRQ111_IRQ         77

#define AVR32_GPIO_IRQ_GROUP          2

/* Instances */
AVR32_HMATRIX DEFINE 0xFFFE1000

/* Instances */
AVR32_MACB DEFINE 0xFFFE1800

/* Interrupts */
#define AVR32_MACB_HRESP_IRQ          512
#define AVR32_MACB_LINK_IRQ           512
#define AVR32_MACB_MFD_IRQ            512
#define AVR32_MACB_PFR_IRQ            512
#define AVR32_MACB_PTZ_IRQ            512
#define AVR32_MACB_RCOMP_IRQ          512
#define AVR32_MACB_RLE_IRQ            512
#define AVR32_MACB_ROVR_IRQ           512
#define AVR32_MACB_RXUBR_IRQ          512
#define AVR32_MACB_TCOMP_IRQ          512
#define AVR32_MACB_TUND_IRQ           512
#define AVR32_MACB_TXERR_IRQ          512
#define AVR32_MACB_TXUBR_IRQ          512

#define AVR32_MACB_IRQ_GROUP          16

/* Instances */
AVR32_PDCA DEFINE 0xFFFF0000

/* Interrupts */
#define AVR32_PDCA_RCZ0_IRQ           96
#define AVR32_PDCA_RCZ1_IRQ           97
#define AVR32_PDCA_RCZ2_IRQ           98
#define AVR32_PDCA_RCZ3_IRQ           99
#define AVR32_PDCA_RCZ4_IRQ           100
#define AVR32_PDCA_RCZ5_IRQ           101
#define AVR32_PDCA_RCZ6_IRQ           102
#define AVR32_PDCA_RCZ7_IRQ           103
#define AVR32_PDCA_RCZ8_IRQ           104
#define AVR32_PDCA_RCZ9_IRQ           105
#define AVR32_PDCA_RCZ10_IRQ          106
#define AVR32_PDCA_RCZ11_IRQ          107
#define AVR32_PDCA_RCZ12_IRQ          108
#define AVR32_PDCA_RCZ13_IRQ          109
#define AVR32_PDCA_RCZ14_IRQ          110
#define AVR32_PDCA_TERR0_IRQ          96
#define AVR32_PDCA_TERR1_IRQ          97
#define AVR32_PDCA_TERR2_IRQ          98
#define AVR32_PDCA_TERR3_IRQ          99
#define AVR32_PDCA_TERR4_IRQ          100
#define AVR32_PDCA_TERR5_IRQ          101
#define AVR32_PDCA_TERR6_IRQ          102
#define AVR32_PDCA_TERR7_IRQ          103
#define AVR32_PDCA_TERR8_IRQ          104
#define AVR32_PDCA_TERR9_IRQ          105
#define AVR32_PDCA_TERR10_IRQ         106
#define AVR32_PDCA_TERR11_IRQ         107
#define AVR32_PDCA_TERR12_IRQ         108
#define AVR32_PDCA_TERR13_IRQ         109
#define AVR32_PDCA_TERR14_IRQ         110
#define AVR32_PDCA_TRC0_IRQ           96
#define AVR32_PDCA_TRC1_IRQ           97
#define AVR32_PDCA_TRC2_IRQ           98
#define AVR32_PDCA_TRC3_IRQ           99
#define AVR32_PDCA_TRC4_IRQ           100
#define AVR32_PDCA_TRC5_IRQ           101
#define AVR32_PDCA_TRC6_IRQ           102
#define AVR32_PDCA_TRC7_IRQ           103
#define AVR32_PDCA_TRC8_IRQ           104
#define AVR32_PDCA_TRC9_IRQ           105
#define AVR32_PDCA_TRC10_IRQ          106
#define AVR32_PDCA_TRC11_IRQ          107
#define AVR32_PDCA_TRC12_IRQ          108
#define AVR32_PDCA_TRC13_IRQ          109
#define AVR32_PDCA_TRC14_IRQ          110

#define AVR32_PDCA_IRQ_GROUP          3

/* Instances */
AVR32_PM DEFINE 0xFFFF0C00

/* Interrupts */
#define AVR32_PM_LOCK0_IRQ            41
#define AVR32_PM_LOCK1_IRQ            41

#define AVR32_PM_IRQ_GROUP            1

/* Instances */
AVR32_PWM DEFINE 0xFFFF3000

/* Interrupts */
#define AVR32_PWM_CHANNEL0_IRQ        384
#define AVR32_PWM_CHANNEL1_IRQ        384
#define AVR32_PWM_CHANNEL2_IRQ        384
#define AVR32_PWM_CHANNEL3_IRQ        384
#define AVR32_PWM_CHANNEL4_IRQ        384
#define AVR32_PWM_CHANNEL5_IRQ        384
#define AVR32_PWM_CHANNEL6_IRQ        384

#define AVR32_PWM_IRQ_GROUP           12

/* Instances */
AVR32_RTC DEFINE 0xFFFF0D00

/* Interrupts */
#define AVR32_RTC_TOPI_IRQ            40

#define AVR32_RTC_IRQ_GROUP           1

/* Instances */
AVR32_SDRAMC DEFINE 0xFFFE2000

/* Interrupts */
#define AVR32_SDRAMC_SDRAMCINTERRUPT_IRQ576

#define AVR32_SDRAMC_IRQ_GROUP        18

/* Instances */
AVR32_SMC DEFINE 0xFFFE1C00

/* Instances */
AVR32_SPI0 DEFINE 0xFFFF2400
AVR32_SPI1 DEFINE 0xFFFF2800

/* Interrupts */
#define AVR32_SPI0_ENDRX_IRQ          288
#define AVR32_SPI0_ENDTX_IRQ          288
#define AVR32_SPI0_MODF_IRQ           288
#define AVR32_SPI0_NSSR_IRQ           288
#define AVR32_SPI0_OVRES_IRQ          288
#define AVR32_SPI0_RDRF_IRQ           288
#define AVR32_SPI0_RXBUFF_IRQ         288
#define AVR32_SPI0_TDRE_IRQ           288
#define AVR32_SPI0_TXBUFE_IRQ         288
#define AVR32_SPI0_TXEMPTY_IRQ        288

#define AVR32_SPI0_IRQ_GROUP          9

/* Interrupts */
#define AVR32_SPI1_ENDRX_IRQ          320
#define AVR32_SPI1_ENDTX_IRQ          320
#define AVR32_SPI1_MODF_IRQ           320
#define AVR32_SPI1_NSSR_IRQ           320
#define AVR32_SPI1_OVRES_IRQ          320
#define AVR32_SPI1_RDRF_IRQ           320
#define AVR32_SPI1_RXBUFF_IRQ         320
#define AVR32_SPI1_TDRE_IRQ           320
#define AVR32_SPI1_TXBUFE_IRQ         320
#define AVR32_SPI1_TXEMPTY_IRQ        320

#define AVR32_SPI1_IRQ_GROUP          10

/* Instances */
AVR32_SSC DEFINE 0xFFFF3400

/* Interrupts */
#define AVR32_SSC_CP0_IRQ             416
#define AVR32_SSC_CP1_IRQ             416
#define AVR32_SSC_ENDRX_IRQ           416
#define AVR32_SSC_ENDTX_IRQ           416
#define AVR32_SSC_OVRUN_IRQ           416
#define AVR32_SSC_RXBUFF_IRQ          416
#define AVR32_SSC_RXRDY_IRQ           416
#define AVR32_SSC_RXSYN_IRQ           416
#define AVR32_SSC_TXBUFE_IRQ          416
#define AVR32_SSC_TXEMPTY_IRQ         416
#define AVR32_SSC_TXRDY_IRQ           416
#define AVR32_SSC_TXSYN_IRQ           416

#define AVR32_SSC_IRQ_GROUP           13

/* Instances */
AVR32_TC DEFINE 0xFFFF3800

/* Interrupts */
#define AVR32_TC_COVFS0_IRQ           448
#define AVR32_TC_COVFS1_IRQ           449
#define AVR32_TC_COVFS2_IRQ           450
#define AVR32_TC_CPAS0_IRQ            448
#define AVR32_TC_CPAS1_IRQ            449
#define AVR32_TC_CPAS2_IRQ            450
#define AVR32_TC_CPBS0_IRQ            448
#define AVR32_TC_CPBS1_IRQ            449
#define AVR32_TC_CPBS2_IRQ            450
#define AVR32_TC_CPCS0_IRQ            448
#define AVR32_TC_CPCS1_IRQ            449
#define AVR32_TC_CPCS2_IRQ            450
#define AVR32_TC_ETRGS0_IRQ           448
#define AVR32_TC_ETRGS1_IRQ           450
#define AVR32_TC_ETRGS2_IRQ           449
#define AVR32_TC_LDRAS0_IRQ           448
#define AVR32_TC_LDRAS1_IRQ           449
#define AVR32_TC_LDRAS2_IRQ           450
#define AVR32_TC_LDRBS0_IRQ           448
#define AVR32_TC_LDRBS1_IRQ           449
#define AVR32_TC_LDRBS2_IRQ           450
#define AVR32_TC_LOVRS0_IRQ           448
#define AVR32_TC_LOVRS1_IRQ           449
#define AVR32_TC_LOVRS2_IRQ           450

#define AVR32_TC_IRQ_GROUP            14

/* Instances */
AVR32_TWI DEFINE 0xFFFF2C00

/* Interrupts */
#define AVR32_TWI_ARBLST_IRQ          352
#define AVR32_TWI_ENDRX_IRQ           352
#define AVR32_TWI_ENDTX_IRQ           352
#define AVR32_TWI_EOSACC_IRQ          352
#define AVR32_TWI_GACC_IRQ            352
#define AVR32_TWI_NACK_IRQ            352
#define AVR32_TWI_OVRE_IRQ            352
#define AVR32_TWI_RXBUFF_IRQ          352
#define AVR32_TWI_RXRDY_IRQ           352
#define AVR32_TWI_SCLWS_IRQ           352
#define AVR32_TWI_SVACK_IRQ           352
#define AVR32_TWI_TXBUFE_IRQ          352
#define AVR32_TWI_TXCOMP_IRQ          352
#define AVR32_TWI_TXRDY_IRQ           352

#define AVR32_TWI_IRQ_GROUP           11

/* Instances */
AVR32_USART0 DEFINE 0xFFFF1400
AVR32_USART1 DEFINE 0xFFFF1800
AVR32_USART2 DEFINE 0xFFFF1C00
AVR32_USART3 DEFINE 0xFFFF2000

/* Interrupts */
#define AVR32_USART0_COMM_RX_IRQ      160
#define AVR32_USART0_COMM_TX_IRQ      160
#define AVR32_USART0_CTSIC_IRQ        160
#define AVR32_USART0_DCDIC_IRQ        160
#define AVR32_USART0_DSRIC_IRQ        160
#define AVR32_USART0_ENDRX_IRQ        160
#define AVR32_USART0_ENDTX_IRQ        160
#define AVR32_USART0_FRAME_IRQ        160
#define AVR32_USART0_ITERATION_IRQ    160
#define AVR32_USART0_NACK_IRQ         160
#define AVR32_USART0_OVRE_IRQ         160
#define AVR32_USART0_PARE_IRQ         160
#define AVR32_USART0_RIIC_IRQ         160
#define AVR32_USART0_RXBRK_IRQ        160
#define AVR32_USART0_RXBUFF_IRQ       160
#define AVR32_USART0_RXRDY_IRQ        160
#define AVR32_USART0_TIMEOUT_IRQ      160
#define AVR32_USART0_TXBUFE_IRQ       160
#define AVR32_USART0_TXEMPTY_IRQ      160
#define AVR32_USART0_TXRDY_IRQ        160

#define AVR32_USART0_IRQ_GROUP        5

/* Interrupts */
#define AVR32_USART1_COMM_RX_IRQ      192
#define AVR32_USART1_COMM_TX_IRQ      192
#define AVR32_USART1_CTSIC_IRQ        192
#define AVR32_USART1_DCDIC_IRQ        192
#define AVR32_USART1_DSRIC_IRQ        192
#define AVR32_USART1_ENDRX_IRQ        192
#define AVR32_USART1_ENDTX_IRQ        192
#define AVR32_USART1_FRAME_IRQ        192
#define AVR32_USART1_ITERATION_IRQ    192
#define AVR32_USART1_NACK_IRQ         192
#define AVR32_USART1_OVRE_IRQ         192
#define AVR32_USART1_PARE_IRQ         192
#define AVR32_USART1_RIIC_IRQ         192
#define AVR32_USART1_RXBRK_IRQ        192
#define AVR32_USART1_RXBUFF_IRQ       192
#define AVR32_USART1_RXRDY_IRQ        192
#define AVR32_USART1_TIMEOUT_IRQ      192
#define AVR32_USART1_TXBUFE_IRQ       192
#define AVR32_USART1_TXEMPTY_IRQ      192
#define AVR32_USART1_TXRDY_IRQ        192

#define AVR32_USART1_IRQ_GROUP        6

/* Interrupts */
#define AVR32_USART2_COMM_RX_IRQ      224
#define AVR32_USART2_COMM_TX_IRQ      224
#define AVR32_USART2_CTSIC_IRQ        224
#define AVR32_USART2_DCDIC_IRQ        224
#define AVR32_USART2_DSRIC_IRQ        224
#define AVR32_USART2_ENDRX_IRQ        224
#define AVR32_USART2_ENDTX_IRQ        224
#define AVR32_USART2_FRAME_IRQ        224
#define AVR32_USART2_ITERATION_IRQ    224
#define AVR32_USART2_NACK_IRQ         224
#define AVR32_USART2_OVRE_IRQ         224
#define AVR32_USART2_PARE_IRQ         224
#define AVR32_USART2_RIIC_IRQ         224
#define AVR32_USART2_RXBRK_IRQ        224
#define AVR32_USART2_RXBUFF_IRQ       224
#define AVR32_USART2_RXRDY_IRQ        224
#define AVR32_USART2_TIMEOUT_IRQ      224
#define AVR32_USART2_TXBUFE_IRQ       224
#define AVR32_USART2_TXEMPTY_IRQ      224
#define AVR32_USART2_TXRDY_IRQ        224

#define AVR32_USART2_IRQ_GROUP        7

/* Interrupts */
#define AVR32_USART3_COMM_RX_IRQ      256
#define AVR32_USART3_COMM_TX_IRQ      256
#define AVR32_USART3_CTSIC_IRQ        256
#define AVR32_USART3_DCDIC_IRQ        256
#define AVR32_USART3_DSRIC_IRQ        256
#define AVR32_USART3_ENDRX_IRQ        256
#define AVR32_USART3_ENDTX_IRQ        256
#define AVR32_USART3_FRAME_IRQ        256
#define AVR32_USART3_ITERATION_IRQ    256
#define AVR32_USART3_NACK_IRQ         256
#define AVR32_USART3_OVRE_IRQ         256
#define AVR32_USART3_PARE_IRQ         256
#define AVR32_USART3_RIIC_IRQ         256
#define AVR32_USART3_RXBRK_IRQ        256
#define AVR32_USART3_RXBUFF_IRQ       256
#define AVR32_USART3_RXRDY_IRQ        256
#define AVR32_USART3_TIMEOUT_IRQ      256
#define AVR32_USART3_TXBUFE_IRQ       256
#define AVR32_USART3_TXEMPTY_IRQ      256
#define AVR32_USART3_TXRDY_IRQ        256

#define AVR32_USART3_IRQ_GROUP        8

/* Instances */
AVR32_USBB DEFINE 0xFFFE0000

/* Interrupts */
#define AVR32_USBB_USB_IRQ_IRQ        544

#define AVR32_USBB_IRQ_GROUP          17

/* Instances */
AVR32_WDT DEFINE 0xFFFF0D30

#endif /* __IAR_SYSTEMS_ASM__*/

#endif

